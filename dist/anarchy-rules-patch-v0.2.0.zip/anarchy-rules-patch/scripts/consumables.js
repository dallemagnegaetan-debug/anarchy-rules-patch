/* ANARCHY // RULES PATCH 0.2.0 — Temporary consumables for sra2 / Foundry 14.
 * Effects are represented as temporary active actor Items. No permanent bonuses.
 * Scene expiration is a deliberate user action; combat expiration is automatic on deleteCombat.
 */
const MOD = 'anarchy-rules-patch';
const attrRR = (attribute) => [{rrType:'attribute',rrTarget:attribute,rrValue:1,rrLabel:''}];
const specRR = (specialization) => [{rrType:'specialization',rrTarget:specialization,rrValue:1,rrLabel:''}];
const skillRR = (skill) => [{rrType:'skill',rrTarget:skill,rrValue:1,rrLabel:''}];
const P = {
  'Alcool / synthanol':{duration:'scene',note:'Ignore les modificateurs de blessure ; désavantage Logique ; risque fort/extrême pour chaque action.'},
  'Bliss':{duration:'scene',note:'Ignore les modificateurs de blessure ; désavantage Volonté.'},
  'Cram':{duration:'combat',note:'+1 point Anarchy par scène d’action ; pas de limite aux actions supplémentaires par tour.',crash:'Blessure grave.'},
  'Deepweed':{duration:'scene',rr:attrRR('willpower'),note:'Perception astrale imposée aux Éveillés.',crash:'Désavantage durant la scène suivante.'},
  'Jazz':{duration:'scene',note:'+1 point Anarchy par scène d’action ; +1 action par narration ; pas de limite aux actions supplémentaires par tour.',crash:'Désavantage durant la scène suivante.'},
  'Kamikaze':{duration:'combat',rr:attrRR('agility'),note:'VD +1 en mêlée ; +1 point Anarchy par scène d’action ; +1 action par narration ; aucune limite aux actions supplémentaires par tour.',crash:'Blessure grave.'},
  'Long cours':{duration:'special',note:'Reste éveillé quatre jours ; seconde dose : deux jours supplémentaires avec désavantage général.',crash:'Sommeil de 24 heures.'},
  'Nitro':{duration:'combat',note:'VD +1 en mêlée ; +1 point Anarchy par scène d’action ; aucune limite aux actions supplémentaires par tour ; ignore les modificateurs de blessure.',crash:'Blessure grave.'},
  'Novacoke':{duration:'scene',rr:[...attrRR('charisma'),...specRR('spec_social-perception')],note:'RR 1 Charisme et RR 1 Perception (sociale).',crash:'Désavantage aux tests Charisme ou Volonté pendant une scène.'},
  'Psyché':{duration:'scene',rr:attrRR('willpower'),sustain:1,note:'RR 1 Volonté et maintien d’un sort supplémentaire. Variante sans sort : niveau 10.'},
  'Zen':{duration:'scene',rr:attrRR('willpower'),note:'RR 1 Volonté ; désavantage aux tests Force ou Agilité.'},
  'Céréprax':{duration:'scene',rr:attrRR('logic'),note:'RR 1 Logique.',crash:'Désavantage Logique pour une scène, plus blessure grave.'},
  'Veille de nuit':{duration:'scene',note:'Vision nocturne.'},
  'Berserker':{duration:'combat',rr:skillRR('close-combat'),note:'BTL, nécessite une IND ; VD +1 en mêlée ; RR 1 Combat rapproché ; risque fort/extrême à chaque action.'},
  'Casanova':{duration:'choice',rr:attrRR('charisma'),note:'BTL, nécessite une IND ; RR 1 Charisme ; durée au choix du MJ.'}
};
const getEffects = actor => actor.items.filter(i=>i.getFlag(MOD,'temporaryConsumable') === true);
const safe = value => foundry.utils.escapeHTML(String(value ?? ''));

async function endEffect(actor,item,{quiet=false}={}) {
  if (!actor?.isOwner || !item || !item.getFlag(MOD,'temporaryConsumable')) return false;
  const crash = item.getFlag(MOD,'crash') || '';
  await actor.deleteEmbeddedDocuments('Item',[item.id]);
  if (!quiet) ui.notifications.info(`Fin de ${item.name.replace(/^EFFET \/\/ /,'')}.`);
  if (crash) {
    ui.notifications.warn(`${actor.name} : contrecoup à appliquer manuellement — ${crash}`);
    if (game.user.isGM) await ChatMessage.create({content:`<p><strong>${safe(actor.name)}</strong> — fin de ${safe(item.name)} : <strong>${safe(crash)}</strong> (application manuelle MJ).</p>`,speaker:ChatMessage.getSpeaker({actor})});
  }
  return true;
}

async function use(actor,itemName) {
  if (!actor || actor.documentName !== 'Actor' || !actor.isOwner) throw Error('Personnage non accessible en écriture.');
  const profile=P[itemName];
  if (!profile) throw Error(`Profil inconnu : ${itemName}`);
  const source=actor.items.find(i=>i.name === itemName && !i.getFlag(MOD,'temporaryConsumable'));
  if (!source) throw Error(`${itemName} doit être présent dans l'inventaire du personnage.`);
  if (getEffects(actor).some(i=>i.getFlag(MOD,'sourceName')===itemName)) throw Error('Cet effet est déjà actif.');
  // Avoid compound buffs that the base game does not arbitrate.
  if (getEffects(actor).length) throw Error('Termine le consommable actif avant d’en utiliser un autre.');
  const rr = profile.rr || [];
  const combat=game.combat;
  const data={
    name:`EFFET // ${itemName}`,type:'feat',img:source.img || 'icons/svg/chemical-bolt.svg',
    system:{featType:'equipment',cost:'equipment',active:true,isFirstFeat:false,rrList:rr,narrativeEffects:[],sustainedSpellCount:profile.sustain||0,description:`<h2>${safe(itemName)}</h2><p>${safe(profile.note)}</p><p><strong>Durée :</strong> ${safe(profile.duration)}</p>${profile.crash?`<p><strong>Contrecoup :</strong> ${safe(profile.crash)}</p>`:''}`,gmDescription:'Effet temporaire créé par ANARCHY // RULES PATCH. Supprimer via son interface de gestion.'},
    flags:{[MOD]:{temporaryConsumable:true,sourceName:itemName,duration:profile.duration,combatId:profile.duration==='combat' ? (combat?.id||null):null,crash:profile.crash||'',activatedAt:Date.now()}}
  };
  await actor.createEmbeddedDocuments('Item',[data]);
  const note=`${itemName} activé sur ${actor.name}. Durée : ${profile.duration}. ${profile.note}${profile.crash?` Contrecoup à l'arrêt : ${profile.crash}`:''}`;
  ui.notifications.info(note);
  return {actor:actor.name,itemName,duration:profile.duration,autoExpiration:profile.duration==='combat' && !!combat};
}

async function open(actor) {
  if (!actor?.isOwner) return ui.notifications.error('Ouvre une fiche de personnage dont tu es propriétaire.');
  const names=actor.items.filter(i=>P[i.name] && !i.getFlag(MOD,'temporaryConsumable')).map(i=>i.name);
  const active=getEffects(actor);
  const options=names.map(n=>`<option value="${safe(n)}">${safe(n)}</option>`).join('');
  const actives=active.map(i=>`<option value="${safe(i.id)}">${safe(i.name)}</option>`).join('');
  const html=`<p><strong>${safe(actor.name)}</strong> — consommables en inventaire : ${names.length}</p><p>Les RR et maintiens magiques sont représentés par un objet temporaire. Points Anarchy, actions, VD, risques, blessures et désavantages restent à appliquer avec le MJ.</p><div class="form-group"><label>Consommable à utiliser</label><select name="itemName">${options}</select></div><div class="form-group"><label>Effet à terminer</label><select name="effectId">${actives}</select></div><p><em>Les effets d'une scène sont terminés manuellement. Les effets « combat » se terminent aussi à la suppression du combat suivi.</em></p>`;
  const buttons=[];
  if(names.length) buttons.push({action:'use',label:'Utiliser',icon:'fas fa-play',callback:(_event,button)=>({action:'use',name:button.form.elements.itemName.value})});
  if(active.length) buttons.push({action:'end',label:'Terminer',icon:'fas fa-stop',callback:(_event,button)=>({action:'end',id:button.form.elements.effectId.value})});
  buttons.push({action:'cancel',label:'Fermer',callback:()=>null});
  const selected=await foundry.applications.api.DialogV2.wait({window:{title:'ANARCHY — Consommables'},content:html,buttons,close:()=>null});
  if(!selected) return;
  try {
    if(selected.action==='use') await use(actor,selected.name);
    else if(selected.action==='end') await endEffect(actor,active.find(i=>i.id===selected.id));
  } catch(e) {console.error(MOD,e);ui.notifications.error(e.message);}
}

async function endAll(actor) {for(const item of [...getEffects(actor)]) await endEffect(actor,item);}
Hooks.once('ready',()=>{
  if(game.system.id!=='sra2') return;
  const mod=game.modules.get(MOD);
  mod.api={...(mod.api||{}),open,use,endEffect,endAll,getEffects,profiles:P};
  Hooks.on('getActorSheetHeaderButtons',(app,buttons)=>{
    const actor=app.actor;
    if(actor?.isOwner)buttons.unshift({label:'Consommables',class:'anarchy-consumables',icon:'fas fa-flask',onclick:()=>open(actor)});
  });
  Hooks.on('getHeaderControlsApplicationV2',(app,controls)=>{
    const actor=app.document;
    if(actor?.documentName==='Actor' && actor.isOwner && !controls.some(b=>b.action==='anarchyConsumables'))controls.unshift({action:'anarchyConsumables',label:'Consommables',icon:'fas fa-flask',onClick:()=>open(actor)});
  });
  Hooks.on('deleteCombat',(combat,_options,userId)=>{
    if(game.user.id!==userId) return;
    for(const actor of game.actors.contents){
      if(!actor.isOwner)continue;
      for(const effect of getEffects(actor)){
        if(effect.getFlag(MOD,'duration')==='combat' && effect.getFlag(MOD,'combatId')===combat.id) void endEffect(actor,effect);
      }
    }
  });
  console.info(`${MOD}: consommables 0.2.0 disponibles`,Object.keys(P));
});
